# Soccer Manager v0.3.2

Hotfix focado no erro `Maximum call stack size exceeded`.

## Correção principal
A V0.3.1 tinha wrappers de funções declaradas novamente com o mesmo nome. Por causa do hoisting de `function` no JavaScript, os aliases usados para chamar a implementação anterior apontavam para a própria função nova, criando recursão infinita.

Foram separadas as implementações-base de:
- `playerDetail`
- `finishMatch`
- `startNextSeason`
- `updatePlayerMatchStats`

Agora as versões estendidas chamam explicitamente as funções-base, sem autorreferência. Isso corrige a falha que impedia a abertura de Elenco e Táticas e também evita o mesmo problema ao finalizar partidas e trocar de temporada.

## Save
A versão usa a chave `soccerManagerV032` e ainda pode carregar o save anterior `soccerManagerV02`.
